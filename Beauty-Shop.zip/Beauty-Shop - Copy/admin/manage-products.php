<?php
session_start();
if (!isset($_SESSION['admin_user'])) {
    header("Location: login.php");
    exit();
}
include '../includes/db.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Manage Products – Diva Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
</head>

<body class="bg-light">
    <div class="container py-5">
        <h2 class="mb-4">📦 Manage Stock & Products</h2>
        <a href="add-product.php" class="btn btn-dark mb-3">➕ Add New Product</a>
        <table class="table table-bordered bg-white">
            <thead class="table-dark">
                <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Update</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
                while ($row = $result->fetch_assoc()):
                ?>
                    <tr>
                        <form method="POST" action="update-stock.php">
                            <td><?= $row['name']; ?></td>
                            <td>$<?= number_format($row['price'], 2); ?></td>
                            <td>
                                <input type="number" name="stock" value="<?= $row['stock']; ?>" class="form-control" min="0" required />
                                <input type="hidden" name="product_id" value="<?= $row['id']; ?>" />
                            </td>
                            <td><button class="btn btn-primary btn-sm" type="submit">Update Stock</button></td>
                        </form>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>

</html>