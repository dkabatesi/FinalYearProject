<?php
session_start();
if (!isset($_SESSION['admin_user'])) {
    header("Location: login.php");
    exit();
}
include '../includes/db.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Orders – Diva Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
</head>

<body class="bg-light">

    <div class="container py-5">
        <h2 class="mb-4">📋 Customer Orders</h2>

        <?php
        $orders = $conn->query("SELECT * FROM orders ORDER BY created_at DESC");
        if ($orders->num_rows > 0):
            while ($order = $orders->fetch_assoc()):
                $order_id = $order['id'];
        ?>
                <div class="card mb-4 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">🧾 Order #<?= $order_id ?> – <?= $order['customer_name']; ?></h5>
                        <p>Email: <?= $order['customer_email']; ?> | Phone: <?= $order['customer_phone']; ?></p>
                        <p><strong>Address:</strong> <?= $order['address']; ?></p>
                        <p><strong>Total:</strong> $<?= number_format($order['total'], 2); ?> | <strong>Date:</strong> <?= $order['created_at']; ?></p>

                        <?php
                        $items = $conn->query("SELECT * FROM order_items WHERE order_id = $order_id");
                        if ($items->num_rows > 0):
                        ?>
                            <table class="table table-bordered mt-3">
                                <thead class="table-light">
                                    <tr>
                                        <th>Product</th>
                                        <th>Qty</th>
                                        <th>Unit Price</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($item = $items->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <?php
                                                $p = $conn->query("SELECT name FROM products WHERE id = " . $item['product_id'])->fetch_assoc();
                                                echo $p ? $p['name'] : 'Unknown';
                                                ?>
                                            </td>
                                            <td><?= $item['quantity']; ?></td>
                                            <td>$<?= number_format($item['price'], 2); ?></td>
                                            <td>$<?= number_format($item['price'] * $item['quantity'], 2); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile;
        else: ?>
            <div class="alert alert-info">No orders have been placed yet.</div>
        <?php endif; ?>
    </div>

</body>

</html>