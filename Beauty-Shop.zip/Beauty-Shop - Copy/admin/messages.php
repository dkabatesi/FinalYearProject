<?php
session_start();
if (!isset($_SESSION['admin_user'])) {
    header("Location: login.php");
    exit();
}
include '../includes/db.php';
$messages = $conn->query("SELECT * FROM messages ORDER BY submitted_at DESC");
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Messages – Diva Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>

<body class="bg-light">
    <div class="container py-5">
        <h2 class="mb-4">📬 Customer Messages</h2>
        <?php if ($messages->num_rows > 0): ?>
            <?php while ($m = $messages->fetch_assoc()): ?>
                <div class="card mb-3">
                    <div class="card-body">
                        <h5><?= $m['name']; ?> <small class="text-muted">– <?= $m['email']; ?></small></h5>
                        <p><?= nl2br($m['message']); ?></p>
                        <small class="text-muted">🕒 <?= $m['submitted_at']; ?></small>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="alert alert-info">No messages yet.</div>
        <?php endif; ?>
    </div>
</body>

</html>