<?php
session_start();
if (!isset($_SESSION['admin_user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Dashboard – Diva Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
</head>

<body>

    <nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <span class="navbar-brand">🛠️ Admin Panel</span>
            <form class="d-flex" action="logout.php" method="POST">
                <button class="btn btn-outline-light btn-sm" type="submit">Logout</button>
            </form>
        </div>
    </nav>
    <?php
    $orders = $conn->query("SELECT COUNT(*) AS total FROM orders")->fetch_assoc()['total'];
    $products = $conn->query("SELECT COUNT(*) AS total FROM products")->fetch_assoc()['total'];
    $messages = $conn->query("SELECT COUNT(*) AS total FROM messages")->fetch_assoc()['total'];
    ?>

    <div class="row mb-4 text-center">
        <div class="col-md-4">
            <div class="bg-white p-3 shadow-sm rounded">
                <h5>🛍 Products</h5>
                <p><?= $products ?></p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="bg-white p-3 shadow-sm rounded">
                <h5>🧾 Orders</h5>
                <p><?= $orders ?></p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="bg-white p-3 shadow-sm rounded">
                <h5>📬 Messages</h5>
                <p><?= $messages ?></p>
            </div>
        </div>
    </div>

    <div class="container py-5">
        <h2 class="mb-4">Welcome back, <?= $_SESSION['admin_user']; ?> 👋</h2>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="card border-primary shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">📦 Manage Products</h5>
                        <p class="card-text">Add, edit or remove products from your collection.</p>
                        <a href="add-product.php" class="btn btn-primary">Go to Products</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-success shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">🧾 View Orders</h5>
                        <p class="card-text">Check recent orders and customer info.</p>
                        <a href="manage-orders.php" class="btn btn-success">View Orders</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-warning shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">📬 Messages</h5>
                        <p class="card-text">Read contact messages from your site visitors.</p>
                        <a href="messages.php" class="btn btn-warning">Read Messages</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>