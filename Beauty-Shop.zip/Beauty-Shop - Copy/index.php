<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Diva Beauty Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">

    <style>
        body {
            scroll-behavior: smooth;
        }

        .hero {
            background: url('assets/images/hero.jpg') center/cover no-repeat;
            color: white;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            font-family: 'Pacifico', cursive;
        }

        .section-title {
            font-weight: bold;
            margin-bottom: 1rem;
        }

        .product-card img {
            transition: transform 0.3s ease;
        }

        .product-card:hover img {
            transform: scale(1.05);
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">DivaBeauty</a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div id="navbarNav" class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link active" href="#home">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#best">About Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container" data-aos="fade-up">
            <h1 class="display-3">Glow Like Never Before</h1>
            <p class="lead">Discover beauty that empowers. Shop our curated collection of premium products.</p>
            <a href="#best" class="btn btn-light btn-lg mt-3">Explore Best Picks</a>
        </div>
    </section>

    <!-- Best Home Section -->
    <section id="best" class="py-5 bg-light">
        <div class="container">
            <h2 class="section-title text-center" data-aos="fade-down">✨ Best Home Picks</h2>
            <div class="row g-4">
                <div class="col-md-4" data-aos="zoom-in">
                    <div class="card product-card">
                        <img src="assets/images/lipstick.jpg" class="card-img-top" alt="Lipstick">
                        <div class="card-body">
                            <h5 class="card-title">Velvet Matte Lipstick</h5>
                            <p class="card-text">Bold color, smooth finish. Your lips deserve this.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4" data-aos="zoom-in" data-aos-delay="100">
                    <div class="card product-card">
                        <img src="assets/images/serum.jpg" class="card-img-top" alt="Serum">
                        <div class="card-body">
                            <h5 class="card-title">Radiance Boost Serum</h5>
                            <p class="card-text">Hydrate, brighten, and glow from within.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4" data-aos="zoom-in" data-aos-delay="200">
                    <div class="card product-card">
                        <img src="assets/images/cleanser.jpg" class="card-img-top" alt="Cleanser">
                        <div class="card-body">
                            <h5 class="card-title">Gentle Foaming Cleanser</h5>
                            <p class="card-text">Clean skin, calm mind. Start fresh every day.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="text-center py-4 bg-dark text-light">
        <p>&copy; <?= date("Y") ?> DivaBeauty. All rights reserved.</p>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>