<?php include 'includes/db.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Our Products – DivaBeauty</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        .product-card img {
            height: 250px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .product-card:hover img {
            transform: scale(1.03);
        }
    </style>
</head>

<body>

    <?php include 'partials/navbar.php'; ?> <!-- optional: you can copy the nav from index.php -->

    <section class="container py-5">
        <h2 class="text-center mb-4">🛍️ Our Beauty Collection</h2>
        <div class="row g-4">
            <?php
            $result = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
            if ($result->num_rows > 0):
                while ($row = $result->fetch_assoc()):
            ?>
                    <div class="col-md-4">
                        <div class="card product-card h-100">
                            <img src="assets/images/products/<?= $row['image']; ?>" class="card-img-top" alt="<?= $row['name']; ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?= $row['name']; ?></h5>
                                <p class="card-text"><?= substr($row['description'], 0, 80); ?>...</p>
                                <p class="fw-bold text-primary">$<?= $row['price']; ?></p>
                                <?php if ($row['stock'] == 0): ?>
                                    <span class="badge bg-danger">Out of Stock</span>
                                <?php elseif ($row['stock'] <= 3): ?>
                                    <span class="badge bg-warning text-dark">Low Stock</span>
                                <?php endif; ?>
                                <?php if ($row['stock'] == 0): ?>
                                    <button class="btn btn-secondary" disabled>Out of Stock</button>
                                <?php else: ?>
                                    <a href="product-details.php?id=<?= $row['id']; ?>" class="btn btn-dark">Add to Cart</a>
                                <?php endif; ?>

                                <a href="product-details.php?id=<?= $row['id']; ?>" class="btn btn-outline-dark">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile;
            else: ?>
                <p class="text-center">No products found.</p>
            <?php endif; ?>
        </div>
    </section>

    <footer class="text-center py-4 bg-dark text-light">
        <p>&copy; <?= date("Y") ?> DivaBeauty. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>