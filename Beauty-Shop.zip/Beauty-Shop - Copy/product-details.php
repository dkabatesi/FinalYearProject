<?php
include 'includes/db.php';

if (!isset($_GET['id'])) {
    die("Product not found.");
}

$product_id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    die("Product not found.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title><?= $product['name']; ?> – DivaBeauty</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        .product-image {
            width: 100%;
            max-height: 450px;
            object-fit: cover;
        }
    </style>
</head>

<body>

    <?php include 'partials/navbar.php'; ?>

    <div class="container py-5">
        <div class="row">
            <div class="col-md-6">
                <img src="assets/images/products/<?= $product['image']; ?>" alt="<?= $product['name']; ?>" class="product-image img-fluid rounded">
            </div>
            <div class="col-md-6">
                <h2><?= $product['name']; ?></h2>
                <p class="text-muted"><?= $product['category']; ?></p>
                <h4 class="text-primary">$<?= $product['price']; ?></h4>
                <p><?= $product['description']; ?></p>
                <p class="text-success">In stock: <?= $product['stock']; ?></p>
                <button class="btn btn-dark mt-2">Add to Cart</button>
                <form action="cart.php" method="POST">
                    <input type="hidden" name="product_id" value="<?= $product['id']; ?>">

                    <?php
                    if (!empty($product['variations'])) {
                        $variations = json_decode($product['variations'], true);
                        foreach ($variations as $label => $options) {
                            echo '<div class="mb-3">';
                            echo "<label class='form-label'>{$label}</label>";
                            echo "<select name='variation[$label]' class='form-select' required>";
                            echo "<option value=''>-- Select {$label} --</option>";
                            foreach ($options as $option) {
                                echo "<option value='{$option}'>{$option}</option>";
                            }
                            echo '</select></div>';
                        }
                    }
                    ?>

                    <div class="mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <input type="number" name="quantity" class="form-control" value="1" min="1" max="<?= $product['stock']; ?>" required>
                    </div>

                    <button type="submit" class="btn btn-dark">Add to Cart</button>
                </form>

            </div>
        </div>
    </div>

    <footer class="text-center py-4 bg-dark text-light">
        <p>&copy; <?= date("Y") ?> DivaBeauty. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>