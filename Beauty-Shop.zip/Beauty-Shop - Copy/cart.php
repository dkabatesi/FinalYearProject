<?php
session_start();
include 'includes/db.php';

// Initialize cart if not already
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle new item from product-details form
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['product_id'])) {
    $id = intval($_POST['product_id']);
    $qty = max(1, intval($_POST['quantity']));
    $variation = isset($_POST['variation']) ? $_POST['variation'] : [];

    // Fetch product details from DB
    $stmt = $conn->prepare("SELECT id, name, price, image FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();

    if ($product) {
        $_SESSION['cart'][] = [
            'id' => $product['id'],
            'name' => $product['name'],
            'price' => $product['price'],
            'image' => $product['image'],
            'quantity' => $qty,
            'variation' => $variation
        ];
        $message = "🛍️ Added to cart: {$product['name']}";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Your Cart – DivaBeauty</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
</head>

<body class="bg-light">

    <div class="container py-5">
        <h2 class="mb-4">🛒 Your Shopping Cart</h2>
        <?php if (!empty($message)): ?>
            <div class="alert alert-success"><?= $message; ?></div>
        <?php endif; ?>

        <?php if (!empty($_SESSION['cart'])): ?>
            <table class="table table-bordered bg-white">
                <thead class="table-dark">
                    <tr>
                        <th>Product</th>
                        <th>Variation</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0;
                    foreach ($_SESSION['cart'] as $item):
                        $item_total = $item['price'] * $item['quantity'];
                        $total += $item_total;
                    ?>
                        <tr>
                            <td>
                                <img src="assets/images/products/<?= $item['image']; ?>" width="50" class="me-2">
                                <?= $item['name']; ?>
                            </td>
                            <td>
                                <?php foreach ($item['variation'] as $label => $value): ?>
                                    <strong><?= $label ?>:</strong> <?= $value ?><br>
                                <?php endforeach; ?>
                            </td>
                            <td><?= $item['quantity']; ?></td>
                            <td>$<?= number_format($item['price'], 2); ?></td>
                            <td>$<?= number_format($item_total, 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="4" class="text-end">Total</th>
                        <th>$<?= number_format($total, 2); ?></th>
                    </tr>
                </tfoot>
            </table>

            <a href="checkout.php" class="btn btn-dark">Proceed to Checkout</a>
        <?php else: ?>
            <div class="alert alert-info">Your cart is currently empty.</div>
        <?php endif; ?>
    </div>

</body>

</html>