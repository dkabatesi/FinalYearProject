<?php
// Change these to match your local or hosted settings
$host = 'localhost';
$user = 'root';
$pass = '';  // usually blank on XAMPP
$db = 'beauty_store';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
