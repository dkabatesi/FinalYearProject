<?php
session_start();
include 'includes/db.php';

if (empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit();
}

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $phone   = trim($_POST['phone']);
    $address = trim($_POST['address']);

    // Calculate total
    $total = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    // Insert order
    $stmt = $conn->prepare("INSERT INTO orders (customer_name, customer_email, customer_phone, address, total) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssd", $name, $email, $phone, $address, $total);
    $stmt->execute();
    $order_id = $conn->insert_id;

    // Insert order items
    $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
    foreach ($_SESSION['cart'] as $item) {
        $item_stmt->bind_param("iiid", $order_id, $item['id'], $item['quantity'], $item['price']);
        $item_stmt->execute();
    }

    $_SESSION['cart'] = []; // clear the cart
    $message = "🎉 Thank you for your order, $name! Your products are on their way.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Checkout – DivaBeauty</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
</head>

<body class="bg-light">

    <div class="container py-5">
        <h2 class="mb-4">🚚 Checkout</h2>

        <?php if ($message): ?>
            <div class="alert alert-success"><?= $message ?></div>
            <a href="index.php" class="btn btn-primary">Return Home</a>
        <?php else: ?>
            <form method="POST" class="bg-white p-4 shadow rounded">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" required />
                </div>
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" required />
                </div>
                <div class="mb-3">
                    <label class="form-label">Phone Number</label>
                    <input type="text" name="phone" class="form-control" required />
                </div>
                <div class="mb-3">
                    <label class="form-label">Shipping Address</label>
                    <textarea name="address" rows="3" class="form-control" required></textarea>
                </div>
                <button type="submit" class="btn btn-dark">Place Order</button>
            </form>
        <?php endif; ?>
    </div>

</body>

</html>